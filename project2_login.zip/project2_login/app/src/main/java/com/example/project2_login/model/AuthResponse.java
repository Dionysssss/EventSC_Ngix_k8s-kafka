package com.example.project2_login.model;

public class AuthResponse {
    private String token;
    private String userId;
    private String role;

    // Getters and setters
}