package com.example.project2_login.model;

public class RegisterRequest {
    private String email;
    private String password;
    private String username;

    public RegisterRequest(String email, String password, String username) {
        this.email = email;
        this.password = password;
        this.username = username;
    }

    // Getters and setters if needed
}